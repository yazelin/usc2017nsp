﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


// including the M2Mqtt Library
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace MQTTClient
{

    public partial class Form1 : Form
    {
        delegate void SetTextCallback(string text);

        MqttClient client;
        string clientId;
        
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            client = new MqttClient("localhost");
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;
            clientId = Guid.NewGuid().ToString();
            client.Connect(clientId);
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            client.Disconnect();
        }
        // this code runs when a message was received
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            // we need this construction because the receiving code in the library and the UI with textbox run on different threads
            SetText(ReceivedMessage); 

        }
        // this code runs when the button "Subscribe" is clicked
        private void btnSubscribe_Click(object sender, EventArgs e)
        {
            if (txtTopicSubscribe.Text != "")
            {
                // whole topic
                string Topic = "IoT/" + txtTopicSubscribe.Text + "/test";

                // subscribe to the topic with QoS 0 ( 0, 1, 2 )
                client.Subscribe(new string[] { Topic }, new byte[] { 0 });   // we need arrays as parameters because we can subscribe to different topics with one call
                SetText("");
            }
            else
            {
                MessageBox.Show("必需輸入訂閱主題!");
            }
        }


        // this code runs when the button "Publish" is clicked
        private void btnPublish_Click(object sender, EventArgs e)
        {
            if (txtTopicPublish.Text != "")
            {
                // whole topic
                string Topic = "IoT/" + txtTopicPublish.Text + "/test";

                // publish a message with QoS 0 ( 0, 1, 2 )
                client.Publish(Topic, Encoding.UTF8.GetBytes(txtPublish.Text), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, true);
            }
            else
            {
                MessageBox.Show("必需輸入發佈主題!");
            }
        }

        private void SetText(string text)
        {
            // we need this construction because the receiving code in the library and the UI with textbox run on different threads
            if (this.RecText.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.RecText.Text = text;
            }
        }

    }
}
